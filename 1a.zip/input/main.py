print("Podaj swoje imię: ")
imie = input()

print("Miło Cię widzieć " + imie)
print("Liczba liter w imieniu: " + str(len(imie)))

wiek = int(input("Podaj swój wiek: "))

print('Twoj wiek za 10 lat: ' + str(wiek+10))

print('Koszulka marki - "Richmond"')

