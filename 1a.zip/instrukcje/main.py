a = 1
b = 1

if a>b:
    print("a jest większe od b")
elif a == 0 and b == 0:
    print("a=0, b=0")
elif a==b:
    print("a jest równe b")
else:
    print("a jest mniejsze od b")


#iteracja

i=1
while i<6:
    print(i)
    if i==3:
        break
    i+=1
else:
    print("ostateczna wartość i =",i)

#pętla for

owoce = ["jabłko","pomarańcza","banan","truskawka","malina","kiwi"]

print(owoce)

for ow in owoce:
    print(ow)

for i in range(1,21,3):
    print("kolejny element pętli",i)

for i,ow in enumerate(owoce):
    print(i+1,":",ow)

for i in range(1,(len(owoce)+1)):
    print(i,owoce[i-1])

print(list(enumerate(owoce)))

cechy = ["kolorowy","czysty","kosztowny","brudny","pstrokaty","interesujący"]
obiekty = ["samochód","budynek","płaszcz","przystanek","ogród","laptop"]


element = []
for cecha in cechy:
    for obiekt in obiekty:
        p = cecha + " " + obiekt
        print(p)
        element.append(p)


print(element)

