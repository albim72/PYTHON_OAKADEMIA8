obywatel = ["Polska","Norwegia","Niemcy","Francja","Włochy"]

print(obywatel)
print(obywatel[1])
obywatel.append("Turcja")
print(obywatel)
obywatel.sort()
print(obywatel)

obywatel.reverse()
print(obywatel)

obywatel.sort(reverse=True)
print(obywatel)

liczby = [34,1,-66,0,45,144,2,3,5,6,12,0,12,12,38,-100,12]

liczby.sort(reverse=True)
print(liczby)

liczby.remove(45)
print(liczby)

liczby.remove(12)
print(liczby)

del liczby[5]
print(liczby)

print(liczby[3:8])
print(liczby[-4:])

sklepzoo = [["pies","kot","papuga","szynszyla"],[7000,2500,7800,22000]]

print(sklepzoo[0])
print(sklepzoo[0][0])
print(sklepzoo[0][0]," - ",sklepzoo[1][0],"zł")
print(sklepzoo[0][1]," - ",sklepzoo[1][1],"zł")
print(sklepzoo[0][2]," - ",sklepzoo[1][2],"zł")
print(sklepzoo[0][3]," - ",sklepzoo[1][3],"zł")

miasto = ["Rzeszów","Kraków","Florencja","Hamburg","Lyon"]
stolica = ["Warszawa","Rzym","Londyn"]

miasto = miasto + stolica

print(miasto)

miasto += ["Zamość","Sandomierz"]

print(miasto)

miasto = miasto*3
print(miasto)

litery = ['a','b','c','d','e','f','g','h']
print('Przed zmianą:',litery)

litery[2:7] = [99,101,111]
print('Po zmianie:',litery)

litery_m = litery
litery_p = list(litery)
litery_q = litery[:]
print('Przed zmianą:',litery)
print('Przed zmianą:',litery_m)
print('Przed zmianą:',litery_p)
print('Przed zmianą:',litery_q)

litery[:] = [1001,1005,1008,1111]
litery_p.remove('h')
print('Po zmianie:',litery)
print('Po zmianie:',litery_m)
print('Po zmianie:',litery_p)
print('Po zmianie:',litery_q)

kolory = ['czerwony','zielony','biały','czarny','brązowy','pomarańczowy']

#stwórz dwie listy: parz i nieparz
#do pierwszej przekaż wszystkie kolory z pozycji parzystych
#do drugiej przekaż wszystkie kolory z pozycji nieparzystych

parz = kolory[::2]
nieparz = kolory[1::2]

print(parz)
print(nieparz)

#odwróć kolejność liter w słowie
s1 = "kajak"
s2 = "pomarańcza"

sw1 = s1[::-1]
sw2 = s2[::-1]

print(s1," -> ", sw1)
print(s2," -> ", sw2)

so = list(s1)
so.reverse()
print(so)

