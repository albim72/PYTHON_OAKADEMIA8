print("to jest pierwszy skrpyt")

imie = "Jan"
print(imie)
print(type(imie))

a = 6
print(a)
print(type(a))

imie = True
print(imie)
print(type(imie))

a = a + 1
print(a)
print(type(a))

c:float
c= 9.42

print(c)
print(type(c))

c = "lato"
print(c)
print(type(c))

imie="Jan"
Imie="Piotr"
print("Witam "+Imie+" i "+imie)

print("imię: " + imie + ", id: " + str(a))
print("imię:",imie,",id:",a,sep=" -- ")
print()

y = 11.7

print(6*y)
r = "88"
print(11*r)
#print(11*float(r))

print(11*eval(r))

q1 = 10
q2 = 11

print(q1+q2,q1-q2,q1*q2,q1/q2,q1%q2,q1**q2,sep="\n")
i = 1
i += 3
print(i)

s = "lajkonik"
print(s)

print(s[0])
print(s[1])
print(s[2:5])
print(s[:4])
print(s[3:])
print(s[-1])
print(s[-2])
print(s[-3:])
print(s[:-3])
print(s[2::2])


