#ditctionary <dict> => (klucz,wartość)

samochod = {
    "marka":"Ford",
    "model":"Mustang",
    "rocznik":1972
}
print(samochod)
print(samochod["model"])
print(samochod.get("model"))
samochod["rocznik"] = 2018
samochod["poj"] = 4.0
print(samochod)
print(len(samochod))
print(samochod.items())
print(samochod.keys())
print(samochod.values())
print("******** klucze słownika *************")
for x in samochod:
    print(x)
print("******** wartości słownika *************")
for y in samochod:
    print(samochod[y])
print("******** wartości słownika po values() *************")
for y in samochod.values():
    print(y)
#szybsza metoda działania ....
print("******** przypadki słownika (krotki) *************")
for x,y in samochod.items():
    print(x,":",y)
autokomis = {
    "auto1":{
        "marka":"Ford",
        "model":"Mustang",
        "rocznik":1972
    },
    "auto2":{
        "marka":"Opel",
        "model":"Insignia",
        "rocznik":2017
    },
    "auto3":{
        "marka":"Jeep",
        "model":"Cherokee",
        "rocznik":2020
    }
}
print(autokomis)
print(autokomis["auto2"])
print(autokomis["auto2"]["marka"])