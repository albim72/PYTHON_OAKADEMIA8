wiek = 34
imie = "Ola"
miasto = "Lublin"

osoba = "Dane klienta -> miasto: {}, imie: {}, wiek: {}."
print(osoba.format(miasto,imie,wiek))

osoba = "Dane klienta -> imię: {1}, wiek: {2}, miasto: {0}."
print(osoba.format(miasto,imie,wiek))

wydzial = "Informatyka"
uczelnia = "Politechnika Śląska"

#f-string
student = f"Student(uczelnia: {uczelnia},wydział: {wydzial}) -> imię:{imie}, wiek:{wiek}, miasto:{miasto}."
print(student)

id = "abc123"
wart = 45.23478

formatowanie = '%-70s = %.3f' %(id,wart)
print(formatowanie)

owoce = [
    ('awokado argentyńskie',7.88),
    ('banan',4.99),
    ('madarynka',10.56),
    ('malina',22),
    ('truskawki',13.22)
]

print("********************************************")
# cennik -> #nr nazwa(10 miejsce) = 0.00 zł
for i,(nazwa,cena) in enumerate(owoce):
    print('#%d: %-10s = %6.2f zł' %(i,nazwa,cena))

print("********************************************")
for i,(nazwa,cena) in enumerate(owoce):
    print('#%d: %-22s = %6.2f zł' %(
        i+1,
        nazwa.title(),
        round(cena,1)
    ))