#krotka -> tuple

animal = ("pies","kot","papuga","królik","szczur","pies")

print(animal)
print(animal.index("kot"))
print(animal[3])
print(animal.count("pies"))
print(len(animal))

if "papuga" in animal:
    print("jest papuga!!!")

if "budynek" in animal:
    print("to jest błąd! - usuń element")
else:
    print("brak elementu w zestawieniu...")

anim2 = ("pająk","ryba")

animal = animal + anim2

print(animal)
print(type(animal))

mojakrotka = tuple(["obiekt56",56,8,77,False,"Toruń",True,10])
print(mojakrotka)
print(type(mojakrotka))

#zmodyfikuj krotkę mojakrotka, usuń element o wartości 56, zamień "Toruń" na "Gdańsk"
#dodaj na ostatniej pozycji wartość 1000

mojalista = list(mojakrotka)
print(mojalista)

mojalista.remove(56)
trn = mojalista.index("Toruń")
mojalista[trn] = "Gdańsk"
mojalista.append(1000)

mojakrotka = tuple(mojalista)

mojalista = None
print(mojakrotka)
print(mojalista)

samochod = ('audi','Q7',4.4,2018,45900)
(marka,model,poj,rok,przebieg) = samochod
print(marka)
print(model)
print(poj)
print(rok)
print(przebieg)

