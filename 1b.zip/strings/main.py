str_ = "mecz sezonu:\nKlub sportowy:\"Orły Wisła\"-\ttrener: Jan Kot\n\t\tvs\n" \
       "Klub sportowy:\"Czerwoni Janowianka\"-\ttrener: Adam Nowak\n"

print(str_)

msg = "     niezwykle Ważna i Tajna widomość;   i Tajna informacja;    jak również Tajna PrzEsYłKA"

#wybrane funkcje klasy str

print(msg)
print(msg.lower())
print(msg.upper())
print(msg.strip())
print(msg.replace("Tajna","Utajniona"))
msglist = msg.split(";")
print(msglist)

for i,d in enumerate(msglist):
       msglist[i] = d.strip()
print(msglist)

print(msg.find("Tajna"))
print(msg.endswith("ka"))
print(msg.endswith("KA"))

d = "pionierzy"
e = "1001"

print(d.isalpha())
print(e.isdigit())

