drzewa = {"buk","dąb","jodła","jesion","baobab","jabłoń"}
print(drzewa)
print(drzewa)
print(drzewa)

for d in drzewa:
    print(d)

print("jesion" in drzewa)
print("osika" in drzewa)

drzewa.add("osika")
print(drzewa)

drzewa.add("dąb")
print(drzewa)

drzewa.update(["topola","świerk","wierzba"])
print(drzewa)

nb = [9,4,12,4,4,9,12,4,9,9,1,12,4,4]

zbnb = set(nb)
print(zbnb)

zbnb.update([7,8,101])
print(zbnb)

nb = list(zbnb)
print(nb)

drzewa.remove("osika")
print(drzewa)

drzewa.discard("jojoba")
print(drzewa)

drzewa.discard("topola")
print(drzewa)

drzewa_m = drzewa.pop()
print(drzewa_m)
print(drzewa)