try:
    print(x)
# except NameError as ec:
#     print(f"{type(ec)} - {ec}: x jest niezefiniowany")
except Exception as d:
    print(f"nieokreślony błąd: {d} - {type(d)}")
finally:
    x = 10
    print(x)

print("ciąg dalszy nastąpi...")