class Kolor:

    #opis stanu - konstruktor
    def __init__(self,id,nazwa):
        self.idkoloru = id
        self.nazwa = nazwa

    #zachownie - funkcje klasy -> metody
    def print_kolor(self):
        print(f"kolor nr {self.idkoloru}, nazwa: {self.nazwa}")



k1 = Kolor(23,"czerwony")
k2 = Kolor(3,"czarny")

k1.print_kolor()
k2.print_kolor()