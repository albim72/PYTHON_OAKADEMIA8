x = lambda a:a+121

print(x(4))
print(x(11.22))

def policza(a):
    return a+121
print(policza(4))

y = lambda x,y=2:2*x-y

print(y(4,8))
print(y(13,8))
print(y(13))

print((lambda a,b,c:a+b*c)(8,1,1.22))

def multi(n):
    return lambda a:a*n

print(multi(99)(4))



def dowolnafunkcja(funkcja,liczba):
    return funkcja(liczba)

print(dowolnafunkcja(lambda x:x+2,88))
print(dowolnafunkcja(lambda x:x*4,11))
print(dowolnafunkcja(lambda txt:4*txt,"Jan"))

def zaproszenie(lgosci):
    return lgosci + 2

print(dowolnafunkcja(zaproszenie,34))






