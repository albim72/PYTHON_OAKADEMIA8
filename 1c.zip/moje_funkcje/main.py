def witaj():
    print("witaj użytkowniku")
    print("opłać abonament")
    print("zaloguj się..")

witaj()
witaj()

#wywołaj funkcję 25 razy
# _ iterator anonimowy
for _ in range(25):
    witaj()

print("+++++++++++++++++++++++++++++++++")


def obywatel(nrtelefonu,kraj="Polska"):
    print(f"pochodzę z kraju: {kraj}, numer telefonu: {nrtelefonu}")

obywatel(5235252,"Holandia")
obywatel(534534534,"Panama")
obywatel(142344234,"Japonia")
obywatel(2352355,"Włochy")
obywatel(56756767)

print("+++++++++++++++++++++++++++++++++")

f=100
def obliczenie(a,b,x):
    global f
    #global definiujemy lokalnie w miejscu użycia
    f = (a+b)*x + f
    return f

print(obliczenie(2,3,5.5))
print(f)

print("+++++++++++++++++++++++++++++++++")

def miasta(miasto3, miasto2="Radom", miasto1="Kraków"):
    print(f"miasto tygodnia: {miasto1}, drugie miejsce: {miasto2}, trzecie miejsce: {miasto3}")

miasta("Gdańsk","Zamość","Wrocław")
miasta("Gdańsk","Zamość")
miasta("Gdańsk")

#wprowadź miasto tygodnia: Kazimierz Dolny, ale pozostaw na drugi pozycji domyślny Radom

miasta("Koszalin",None,"Kazimierz Dolny")
miasta("Koszalin",miasto1="Kazimierz Dolny")

def zamek(id,*zamki,rabat,**eventy):
    #*nazwa - > lista argumentów
    #**nazwa - > słownik argumentów
    print(f"Zamek tygodnia: id -> {id}, {zamki[0]}, rabat -> {rabat} zł, drugie miejsce: {zamki[1]}, trzecie miejsce: {zamki[2]}")

zamek(1,"Malbork","Ogrodzieniec","Będzin",rabat=20)
zamek(2,"Janowiec","Malbork","Czersk","Ogrodzieniec","Będzin","Olsztyn",rabat=5)
zamek(2,rabat=0)




