import os

f = open("dane.txt","r",encoding="utf-8")
print(f.readline())
print(f.readline())
print(f.readline())
print(f.readline())
f.close()

f = open("dane.txt","r",encoding="utf-8")
for linia in f:
    print(linia)
f.close()

f = open("dane.txt","r",encoding="utf-8")
print(f.readline())
print(f.readline())
print(f.read())
f.close()

g = open("message.txt","a",encoding="utf-8")
g.write("to jest ważna informacja\n")
g.close()

g = open("message.txt","r",encoding="utf-8")
print(g.read())
g.close()

if os.path.exists("message.txt"):
    os.remove("message.txt")
    print("plik został usunięty...")
else:
    print("plik nie istnieje...")


