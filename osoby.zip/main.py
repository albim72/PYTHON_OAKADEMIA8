class Sport:

    def __init__(self,dyscyplina,lataupr,best_wynik):
        self.dyscyplina = dyscyplina
        self.lataupr = lataupr
        self.best_wynik = best_wynik

    def infosport(self):
        print(f"dysycyplina sportu: {self.dyscyplina}, lata uprawiania: {self.lataupr}, "
              f"życiówka: {self.best_wynik}")

class Osoba():

    def __init__(self,imie,wiek,waga,wzrost):
        self.imie = imie
        self.wiek = wiek
        self.waga = waga
        self.wzrost = wzrost
        self.kolor_oczu = "brązowy"
        self.informacja()

    def informacja(self):
        print("tworzenie nowej osoby.....")

    def print_osoba(self):
        print(f"osoba -> imię: {self.imie}, wiek: {self.wiek} lat, "
              f"waga: {self.waga} kg, wzrost: {self.wzrost} cm, kolor oczu: {self.kolor_oczu}")

    def wiekza10lat(self):
        return self.wiek + 10

    def czypracownik(self):
        return False

    def bmi(self):
        return self.waga/(self.wzrost/100)**2


p1 = Osoba("Jan",45,99,173)
p1.print_osoba()
wz = p1.wiekza10lat()
print(f"wiek osoby za 10 lat: {wz}")
print(f"czy osoba jest pracownikiem? {p1.czypracownik()}")
print(f"BMI ciała wynosi: {p1.bmi():.2f}")



print("______________________________________________")
p2 = Osoba("Olga",23,51,170)
p2.kolor_oczu = "niebieski"
p2.print_osoba()
wz = p2.wiekza10lat()
print(f"wiek osoby za 10 lat: {wz}")
print(f"czy osoba jest pracownikiem? {p2.czypracownik()}")


class Pracownik(Osoba):

    #konstruktor z dziedziczeniem
    def __init__(self,imie,wiek,waga,wzrost,firma,stanowisko,latapracy,wynagrodzenie):
        super().__init__(imie,wiek,waga,wzrost)
        self.firma = firma
        self.stanowisko = stanowisko
        self.latapracy = latapracy
        self.wynagrodzenie = wynagrodzenie

    def print_pracownik(self):
        print(f"dane pracownika -> firma: {self.firma}, stanowisko pracy: {self.stanowisko},"
              f"lata pracy: {self.latapracy}, wynagrodzenie: {self.wynagrodzenie}, kolor_oczu: {self.kolor_oczu}")

    def czypracownik(self):
        return True

print("_______________________________________________________")
e1 = Pracownik("Olaf",41,87,178,"ABC","dyrektor",12,10900)
e1.print_osoba()
e1.print_pracownik()
wz = e1.wiekza10lat()
print(f"wiek osoby za 10 lat: {wz}")
print(f"czy osoba jest pracownikiem? {e1.czypracownik()}")


class Pusta:pass

class Student(Pracownik,Sport,Pusta):

    #konstruktor z wielodziedziczeniem
    def __init__(self,imie,wiek,waga,wzrost,nr_studenta,kierunek,rok_st,
                 firma="",stanowisko="",latapracy="",wynagrodzenie="",dyscyplina="",lataupr="",best_wynik=""):
        Pracownik.__init__(self,imie,wiek,waga,wzrost,firma,stanowisko,latapracy,wynagrodzenie)
        Sport.__init__(self,dyscyplina,lataupr,best_wynik)
        self.nr_studenta = nr_studenta
        self.kierunek = kierunek
        self.rok_st = rok_st

    def print_student(self):
        print(f"student -> id:{self.nr_studenta}, kierunek: {self.kierunek}, rok studiów: {self.rok_st}")

    def czypracownik(self):
        return self.firma != ""

print("________________________________________________________")
s1 = Student("Olaf",22,100,174,65446,"budowa mostów",3)
s1.print_osoba()
s1.print_student()
wz = s1.wiekza10lat()
print(f"wiek osoby za 10 lat: {wz}")
print(f"czy osoba jest pracownikiem? {s1.czypracownik()}")


print("________________________________________________________")
s2 = Student("Ola",21,48,165,54554,"informatyka",2,"XYZ","junior developer",1,2500)
s2.print_osoba()
s2.print_student()
s2.print_pracownik()
wz = s2.wiekza10lat()
print(f"wiek osoby za 10 lat: {wz}")
print(f"czy osoba jest pracownikiem? {s2.czypracownik()}")

print("________________________________________________________")
s3 = Student("Olaf",22,75,174,65446,"budowa mostów",3,dyscyplina="biegi ultra",lataupr=5,
             best_wynik="102km 18h 45min 56s")
s3.print_osoba()
s3.print_student()
s3.infosport()
wz = s3.wiekza10lat()
print(f"wiek osoby za 10 lat: {wz}")
print(f"czy osoba jest pracownikiem? {s3.czypracownik()}")
print(f"BMI ciała wynosi: {s3.bmi():.2f}")

